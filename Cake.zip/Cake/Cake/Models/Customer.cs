﻿using System;
using System.Collections.Generic;

namespace Cake.Models
{
    public partial class Customer
    {
        public Customer()
        {
            Orders = new HashSet<Order>();
            PaymentMethods = new HashSet<PaymentMethod>();
            Products = new HashSet<Product>();
        }

        public int Cid { get; set; }
        public string? Cname { get; set; }
        public string? Address { get; set; }
        public string? Mobileno { get; set; }

        public virtual ICollection<Order> Orders { get; set; }
        public virtual ICollection<PaymentMethod> PaymentMethods { get; set; }
        public virtual ICollection<Product> Products { get; set; }
    }
}
