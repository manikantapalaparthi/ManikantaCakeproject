﻿using System;
using System.Collections.Generic;

namespace Cake.Models
{
    public partial class PaymentMethod
    {
        public int Payid { get; set; }
        public string? Paymenttype { get; set; }
        public int? Cid { get; set; }

        public virtual Customer? CidNavigation { get; set; }
    }
}
