﻿using System;
using System.Collections.Generic;

namespace Cake.Models
{
    public partial class Product
    {
        public Product()
        {
            Orders = new HashSet<Order>();
        }

        public int Productid { get; set; }
        public string? Productname { get; set; }
        public int? Productcost { get; set; }
        public int? Cid { get; set; }

        public virtual Customer? CidNavigation { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
}
