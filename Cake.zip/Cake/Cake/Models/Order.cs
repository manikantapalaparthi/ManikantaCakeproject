﻿using System;
using System.Collections.Generic;

namespace Cake.Models
{
    public partial class Order
    {
        public int Orderid { get; set; }
        public int? Productid { get; set; }
        public int? Cid { get; set; }
        public string? Productname { get; set; }
        public DateTime Orderdate { get; set; }

        public virtual Customer? CidNavigation { get; set; }
        public virtual Product? Product { get; set; }
    }
}
